# Hands-on 4 - Difference between JPA, Hibernate and Spring Data JPA

## JPA
- Specification (JSR 338)
- Defines ORM standards
- No implementation

## Hibernate
- ORM framework
- Implements JPA

## Spring Data JPA
- Built on top of JPA
- Reduces boilerplate code
- Uses JpaRepository
- Manages transactions
