import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
}

@Service
class EmployeeService{

    @Autowired
    private EmployeeRepository employeeRepository;

    @Transactional
    public void addEmployee(Employee employee){
        employeeRepository.save(employee);
    }
}
